README
By Gunner Rya
24th Jan 2022
/////////////////////////////////////////////////////////

Thank you for downloading the template and actually checking this file first.
Please read this file in its entirity if you are new to making missions.
Please use the template properly to ensure that radios and babel are set correctly etc.
If you find any issues with the template mission or this file, eg spellnig, then please contact Gunner or Grumpy on discord.

/////////////////////////////////////////////////////////

1 - Folder Name/ First Steps

Do not edit this folder. Copy and paste the mission and rename it to your desired mission name.

Our standard format looks a little like:

(CO32)OperationTacticoolV1_0_0.altis

Co means coop, adv means adversarial and gmk means gimmick.
After the brackets, use your mission name followed by a version number (no full stops).
After the version number, you need to have a full stop followed by the map name. This should be set automatically if you are using the correct template (please do).

/////////////////////////////////////////////////////////

2 - In-game Attributes

Make sure you rename the mission in-game by going to attributes-> general, then changing the mission name there to match the folder name.
Change the author to your name. Do not meme it, or we will reject your mission or fix it ourselves.
Ensure your independents allegiance is set appropriately - Arma can set greenfor units to friendly or hostile to other factions. Make sure it is set correctly for you.
Change your summary by going to attributes-> multiplayer, then adding a summary. If there are required slots for the mission (eg MAT team), then list them here. If posssible, give a very brief overview of the mission objectives.

/////////////////////////////////////////////////////////

3 - Selecting Player Units

Delete all factions other than players.
Delete unecessary slots and unused assets (eg mortar teams) and command elements (eg UAV operator). DO NOT DELETE PLATOON LEAD, PLATOON MEDIC, PLATOON SGT OR ANY SLOTS FROM ALPHA, BRAVO OR CHARLIE.
If you change the role of a slot (eg, from A1 AR to Grenadier), then ensure you change the role description by double clicking on the unit and editing the field 'Role Description.' The example given before would look like: Grenadier@AAF Alpha 1
If you add more slots, ensure that the radios and Orbat markers are appropriately set. It is highly recommended to use the pre-placed units in the modset to avoid this hassle.
If you deleted a slot you want to use, you can reopen the original template mission and copy and paste the slot between missions.

/////////////////////////////////////////////////////////

4 - Enemy Placement

Make sure enemies have waypoints - useful waypoints are - TMF Garrison, TMF patrol and hold markers.
We recommend 120-200 EI per mission - if they are unarmoured, this should be on the higher end, if they are armoured and well equipped, it should be on the lower end.
Do not overdesign their placement.
Do not place many grenadiers.
Ensure players can combat enemy equipment - if they have a tank, we should have ample AT.
Ensure the enemy can combat us - if we have a tank, they should have AT.
Spread enemy forces out over several square kilometers.

/////////////////////////////////////////////////////////

5 - Loadout

Use the templates already in the file as a template. Do not change medical supplies or ammunition count without a good reason.
Use the autotest feature to ensure there is enough space in inventories/ compatible ammunition etc by going to TMF - TMF autotest.
There is a more thorough loadout guide available on the website.
Change the displayname in the briefing.ext to something appropriate - do not leave it on the example.

/////////////////////////////////////////////////////////

6 - Mission Design

Once you have found a location for your mission and the friendly spawn, attempt to travel the distance and see how long it takes. A 10 minute drive at mission start is not ideal.
Keep things dynamic and avoid an overreliance on scripting.
Expect players to do unexpected things.

/////////////////////////////////////////////////////////

7 - Briefing

Keep it short and to the point. Some flavour is good, but if it is too long, then players will not read it. Be overly specific if the mission is complicated.

briefing_nato.sqf = blufor briefing
briefing_csat.sqf = opfor briefing
briefing_aaf.sqf = greenfor briefing